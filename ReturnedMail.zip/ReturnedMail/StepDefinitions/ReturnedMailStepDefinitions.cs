using System;
using TechTalk.SpecFlow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMDDatabaseAccess.Database;
using EMDDatabaseAccess.Database.Context;
using EMDDatabaseAccess.DataModels.EmptorDB;
using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using ReturnedMail.Support;

namespace ReturnedMail.StepDefinitions
{
    [Binding]
    [CollectionDefinition("SpecFlowNonParallelizableFeatures", DisableParallelization = true)]
    public class ReturnedMailStepDefinitions
    {
        
        [When(@"Job Job_EMD_FileCreation_ReturnedMail is run")]
        public void WhenJobJob_EMD_FileCreation_ReturnedMailIsRun()
        {
            DatabaseHelper.EMD.RunAgentJob("Job_EMD_FileCreation_ReturnedMail");
        }

        [When(@"Job Job_EMD_FileCreation_ReturnedMailMI is run")]
        public void WhenJobJob_EMD_FileCreation_ReturnedMailMIIsRun()
        {
            DatabaseHelper.EMD.RunAgentJob("Job_EMD_FileCreation_ReturnedMailMI");
        }

    }
}
