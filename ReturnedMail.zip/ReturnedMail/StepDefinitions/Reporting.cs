using System;
using TechTalk.SpecFlow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMDDatabaseAccess.Database;
using EMDDatabaseAccess.Database.Context;
using EMDDatabaseAccess.DataModels.EmptorDB;
using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using ReturnedMail.Support;

namespace ReturnedMail.StepDefinitions
{
    [Binding]
    [CollectionDefinition("SpecFlowNonParallelizableFeatures", DisableParallelization = true)]
    public class Reporting
    {
       
        [Given(@"There is following data in WRK_ReturnedMailCustomerDetails")]
        public void ThereisfollowingdatainWRK_ReturnedMailCustomerDetails(Table table)
        {
            var data = table.CreateSet<WRK_ReturnedMailCustomerDetails>().ToList();
            DatabaseHelper.EMD.RunReturnedCustomerLoad(data);
         
        }
        [When(@"Stored procedure is run")]
        public void storedProcedureIsRun()
        {
            DatabaseHelper.EMD.RunReturnedMailStoredProcedure();
        }
        [Then(@"Following data is present in RM_MI_Exception")]
        public void FollowingdataispresentinRM_MI_ExceptionID(Table expectedResults)
        {
            // Compare expected results with actual to see if data exists
            expectedResults.CompareToSet<RM_MI_Exception>(DatabaseHelper.EMD.RM_MI_Exception());
        }
        [Then(@"Following data is present in RM_MI_Measure")]
        public void ThenFollowingDataIsPresentInRM_MI_Measure(Table expectedResults)
        {
            expectedResults.CompareToSet<RM_MI_Measure>(DatabaseHelper.EMD.RM_MI_Measure());
        }
        [Then(@"Following data is present in RM_MI_Measure_Summary_View")]
        public void ThenFollowingDataIsPresentInRM_MI_Measure_Summary_View(Table expectedResults)
        {
            expectedResults.CompareToSet<RM_MI_Measure_Summary_View>(DatabaseHelper.EMD.RM_MI_Measure_Summary_View());
        }

        [Then(@"Following data is present in RM_MI_Exception_Summary_View")]
        public void ThenFollowingDataIsPresentInRM_MI_Exception_Summary_View(Table expectedResults)
        {
            expectedResults.CompareToSet<RM_MI_Exception_Summary_View>(DatabaseHelper.EMD.RM_MI_Exception_Summary_View());
            
        }

        [Then(@"Following data should be present in RM_MI_Detail_View")]
        public void ThenFollowingDataShouldBePresentInRM_MI_Detail_View(Table expectedResults)
        {
            expectedResults.CompareToSet<RM_MI_Detail_View>(DatabaseHelper.EMD.RM_MI_Detail_View());
        }









    }
}
