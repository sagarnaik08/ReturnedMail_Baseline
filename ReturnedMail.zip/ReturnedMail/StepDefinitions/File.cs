using System;
using TechTalk.SpecFlow;
using System.IO;
using System.Linq;

namespace ReturnedMail.StepDefinitions
{

    [Binding]
    [CollectionDefinition("SpecFlowNonParallelizableFeatures", DisableParallelization = true)]
    public class File
    {
        
        private static readonly Dictionary<string, string> pickexpectedFile = new Dictionary<string, string>()
        {
            {"returnedMailFile",@"\\DVEMPTORSW01.devadmin.nbsdev.co.uk\FTPDVEMPTORSW01\EMD\ReturnedMail" },
            {"returnedMailMIFile",@"\\DVEMPTORSW01.devadmin.nbsdev.co.uk\FTPDVEMPTORSW01\EMD\ReturnedMailMI" },
            {"expectedEmailFile","C:\\ReturnedMail_TestAutomation\\ReturnedMail\\ReturnedMail\\Config\\ExpectedEmailFile.txt" },
            {"expectedNoEmailFile","C:\\ReturnedMail_TestAutomation\\ReturnedMail\\ReturnedMail\\Config\\ExpectedNoEmailFile.txt" },
            {"expectedSmsFile","C:\\ReturnedMail_TestAutomation\\ReturnedMail\\ReturnedMail\\Config\\ExpectedSmsFile .txt" },
            {"expectedNoSmsFile","C:\\ReturnedMail_TestAutomation\\ReturnedMail\\ReturnedMail\\Config\\ExpectedNoSmsFile.txt" },
            {"expExcepFile-EmMobPresentFile","C:\\ReturnedMail_TestAutomation\\ReturnedMail\\ReturnedMail\\Config\\ExpExcepFile-EmMobPresentFile.txt" },
            {"expExcepFile-NoEmMobPresentFile","C:\\ReturnedMail_TestAutomation\\ReturnedMail\\ReturnedMail\\Config\\ExpExcepFile-NoEmMobPresentFile.txt" },
            {"expMeasFile-EmMobPresentFile","C:\\ReturnedMail_TestAutomation\\ReturnedMail\\ReturnedMail\\Config\\ExpMeasFile-EmMobPresentFile.txt" },
            {"expMeasFile-NoEmMobPresentFile","C:\\ReturnedMail_TestAutomation\\ReturnedMail\\ReturnedMail\\Config\\ExpMeasFile-NoEmMobPresentFile.txt" }
        };
       
        [Then(@"""([^""]*)"" should be successfully generated at returnedMail location")]
        public void ThenShouldBeSuccessfullyGeneratedAtReturnedMailLocation(string fileName)
        {
            
            var folderPath = pickexpectedFile[fileName];
            bool results = false;
            
            if (Directory.Exists(folderPath))
            {
                string filenamever = folderPath;
                string[] files = Directory.GetFiles(folderPath);
                if (files.Length == 2)
                {
                    results = true;

                }
                results.Should().BeTrue();
            }

            
        }

        [Then(@"ActualEmailFile should be matching with ""([^""]*)""")]
        public void ThenActualEmailFileShouldBeMatchingWith(string fileName)
        {
            bool emailResult = false;
            var expectedEmailFile= pickexpectedFile[fileName];
            var filePath = @"\\DVEMPTORSW01.devadmin.nbsdev.co.uk\FTPDVEMPTORSW01\EMD\ReturnedMail";
            string[] files=Directory.GetFiles(filePath);
            string actualEmailFile = files[0];
            var areEqual=System.IO.File.ReadLines(actualEmailFile).SequenceEqual(System.IO.File.ReadAllLines(expectedEmailFile));
            if(areEqual==true)
            {
                emailResult = true;
            }
            emailResult.Should().BeTrue();
        }

        [Then(@"ActualSmsFile should be matching with ""([^""]*)""")]
        public void ThenActualSmsFileShouldBeMatchingWith(string fileName)
        {
            bool emailResult = false;
            var expectedSmsFile = pickexpectedFile[fileName];
            var filePath = @"\\DVEMPTORSW01.devadmin.nbsdev.co.uk\FTPDVEMPTORSW01\EMD\ReturnedMail";
            string[] files = Directory.GetFiles(filePath);
            string actualSmsFile = files[1];
            var areEqual = System.IO.File.ReadLines(actualSmsFile).SequenceEqual(System.IO.File.ReadAllLines(expectedSmsFile));
            if (areEqual == true)
            {
                emailResult = true;
            }
            emailResult.Should().BeTrue();
        }

        [Then(@"Actual measure file should match with ""([^""]*)""")]
        public void ThenActualMeasureFileShouldMatchWith(string fileName)
        {
            bool measureResults = false;
            var expMeasFile = pickexpectedFile[fileName];
            var filePath = @"\\DVEMPTORSW01.devadmin.nbsdev.co.uk\FTPDVEMPTORSW01\EMD\ReturnedMailMI";
            string[] files = Directory.GetFiles(filePath);
            string actualMeasFile= files[1];
            bool areEqual=System.IO.File.ReadLines(actualMeasFile).SequenceEqual(System.IO.File.ReadAllLines(expMeasFile));
            if(areEqual==true)
            {
                measureResults = true;
            }
            measureResults.Should().BeTrue();   
        }

        [Then(@"Actual exception file should match with ""([^""]*)""")]
        public void ThenActualExceptionFileShouldMatchWith(string fileName)
        {
            bool exceptionResults = false;
            var expExcepFile = pickexpectedFile[fileName];
            var filePath = @"\\DVEMPTORSW01.devadmin.nbsdev.co.uk\FTPDVEMPTORSW01\EMD\ReturnedMailMI";
            string[] files = Directory.GetFiles(filePath);
            string actualExcepFile = files[0];
            bool areEqual = System.IO.File.ReadLines(actualExcepFile).SequenceEqual(System.IO.File.ReadAllLines(expExcepFile));
            if (areEqual == true)
            {
                exceptionResults = true;
            }
            exceptionResults.Should().BeTrue();
        }







    }
}
