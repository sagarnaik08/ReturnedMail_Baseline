﻿using EMDDatabaseAccess.Database;
using EMDDatabaseAccess.Database.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReturnedMail.Support
{
    public class DatabaseHelper
    {
        public static EMDContext EMDContext = new EMDContext();
        public static EMD EMD = new EMD(EMDContext);
        public static CISODSContext CISODSContext = new CISODSContext();
        public static CISODS CISODS = new CISODS(CISODSContext);
    }
}
