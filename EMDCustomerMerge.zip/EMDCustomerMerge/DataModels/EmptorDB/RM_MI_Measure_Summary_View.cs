﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class RM_MI_Measure_Summary_View
    {
        [Column("ExtractDate")]
        public DateOnly ExtractDate { get; set; }

        [Column("ExtractDay")]
        public string ExtractDay { get; set; }

        [Column("ReturnedMailServiceAlerts_COUNT")]
        public int ReturnedMailServiceAlerts_COUNT { get; set; }

        [Column("MobileNumberUnavailable_COUNT")]
        public int MobileNumberUnavailable_COUNT { get; set; }

        [Column("EmailAddressUnavailable_COUNT")]
        public int EmailAddressUnavailable_COUNT { get; set; }

        [Column("MobileNumberAndEmailAddressUnavailable_COUNT")]
        public int MobileNumberAndEmailAddressUnavailable_COUNT { get; set; }

        [Column("ReturnedMailSMSFile_COUNT")]
        public int ReturnedMailSMSFile_COUNT { get; set; }

        [Column("ReturnedMailEmailFile_COUNT")]
        public int ReturnedMailEmailFile_COUNT { get; set; }

   
    }
}
