﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class AuditTable
    {
        public int AuditID { get; set; }
        public decimal MergedTo { get; set; }
        public decimal MergedFrom { get; set; }
        public DateTime? MergedDateTime { get; set; }
        public DateTime? DemergedDateTime {get;set;}
    }
}
