﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class RM_MI_Exception_Summary_View
    {
        [Column("ExtractDate")]
        public DateOnly ExtractDate { get; set; }

        [Column("ExtractDay")]
        public string ExtractDay { get; set; }

        [Column("PartyID")]
        public decimal PartyID { get; set; }

        [Column("MobileNumberAndEmailAddressUnavailable_IND")]
        public int MobileNumberAndEmailAddressUnavailable_IND { get; set; }

        [Column("PrimeExceptionReason")]
        public string PrimeExceptionReason { get; set; }

      
    }
}
