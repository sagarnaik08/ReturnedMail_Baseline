﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class RM_MI_Measure
    {
        [Column("RM_MI_MeasureID")]
        public int RM_MI_MeasureID { get; set; }

        [Column("ReturnedMailServiceAlerts_COUNT")]
        public int ReturnedMailServiceAlerts_COUNT { get; set; }

        [Column("MobileNumberUnavailable_COUNT")]
        public int MobileNumberUnavailable_COUNT { get; set; }

        [Column("EmailAddressUnavailable_COUNT")]
        public int EmailAddressUnavailable_COUNT { get; set; }

        [Column("MobileNumberAndEmailAddressUnavailable_COUNT")]
        public int MobileNumberAndEmailAddressUnavailable_COUNT { get; set; }

        [Column("ReturnedMailSMSFile_COUNT")]
        public int ReturnedMailSMSFile_COUNT { get; set; }

        [Column("ReturnedMailEmailFile_COUNT")]
        public int ReturnedMailEmailFile_COUNT { get; set; }

        [Column("LogID")]
        public Int64 LogID { get; set; }
    }
}
