﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class CustomerMerge
    {
        [Column("CurrentCISNumber")]
        public decimal CurrentCISNumber { get; set; }

        [Column("MergedFrom")]
        public decimal MergedFrom { get; set; }

        [Column("MergedTo")]
        public decimal MergedTo { get; set; }

        [Column("MergeDate")]
        public DateTime MergeDate { get; set; }

    }
}
