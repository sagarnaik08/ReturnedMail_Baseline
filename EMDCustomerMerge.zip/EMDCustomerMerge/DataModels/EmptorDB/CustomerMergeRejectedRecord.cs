﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class CustomerMergeRejectedRecord
    {
        [Column("RejectId")]
        public int RejectId { get; set; }

        [Column("MergedFrom")]
        public decimal MergedFrom { get; set; }

        [Column("MergedTo")]
        public decimal MergedTo { get; set; }

        [Column("MergeDate")]
        public decimal MergeDate { get; set; }

        [Column("CISId")]
        public string CISId { get; set; }

        [Column("InsertDatetime")]
        public DateTime InsertDatetime { get; set; }

        [Column("RejectReason")]
        public string RejectReason { get; set; }

    }
}

