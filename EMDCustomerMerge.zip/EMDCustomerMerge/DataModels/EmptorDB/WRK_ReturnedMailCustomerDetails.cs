﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class WRK_ReturnedMailCustomerDetails
    {
        [Column("PartyId")]
        public decimal PartyId { get; set; }

        [Column("AlertCreatedDate")]
        public DateTime? AlertCreatedDate { get; set; }
    }
}
