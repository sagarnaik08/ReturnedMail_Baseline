﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class ProcessLog
    {
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        [Column("LogID")]
        public decimal LogID { get; set; }

        [Column("ProcessID")]
        public int ProcessID { get; set; }

        [Column("StartTime")]
        public DateTime? StartTime { get; set; }

        [Column("EndTime")]
        public DateTime? EndTime { get; set; }

        [Column("Status")]
        public string Status { get; set; }

    }
}
