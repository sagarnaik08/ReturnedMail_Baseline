﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class RM_MI_Exception
    {
        [Column("RM_MI_ExceptionID")]
        public int RMMIExceptionID { get; set; }

        [Column("PartyId")]
        public decimal PartyId { get; set; }
       
        [Column("MobileNumberAndEmailAddressUnavailable_IND")]
        public int MobileNumberAndEmailAddressUnavailable_IND { get; set; }
        
        [Column("PrimeExceptionReason")]
        public string? PrimeExceptionReason { get; set; }
        
        [Column("RM_MI_MeasureID")]
        public int RM_MI_MeasureID { get; set; }

        [Column("LogID")]
        public Int64 LogID { get; set; }
    }
}
