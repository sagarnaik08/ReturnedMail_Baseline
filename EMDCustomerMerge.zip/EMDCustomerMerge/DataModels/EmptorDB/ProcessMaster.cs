﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMDDatabaseAccess.DataModels.EmptorDB
{
    public class ProcessMaster
    {
        [Column("ProcessID")]
        public int ProcessID { get; set; }

        [Column("ProcessType")]
        public string ProcessType { get; set; }

        [Column("ProcessName")]
        public string ProcessName { get; set; }

        [Column("ProcessDescription")]
        public string ProcessDescription { get; set; }

        [Column("ParentProcessID")]
        public decimal? ParentProcessID { get; set; }

    }
}
