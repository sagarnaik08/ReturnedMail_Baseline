﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace EMDDatabaseAccess.DataModels.CISODS
{
    public class BU022
    { 

        [Column("CUSNBRMRG")]
        public decimal CUSNBRMRG { get; set; }

        [Column("CUSNBR")]
        public decimal CUSNBR { get; set; }

        [Column("GLB_DTIME")]
        public string GLB_DTIME { get; set; }

        [Column("LASBUDIDY")]
        public decimal LASBUDIDY { get; set; }

        [Column("LASUSRIDF")]
        public string LASUSRIDF { get; set; }

        [Column("MRGDTE")]
        public decimal MRGDTE { get; set; }

        [Column("RUNNBR")]
        public string RUNNBR { get; set; }

        [Column("RVSCGYCNF")]
        public string RVSCGYCNF { get; set; }

    }
}
