﻿using EMDDatabaseAccess.Database.Context;
using EMDDatabaseAccess.DataModels.CISODS;

namespace EMDDatabaseAccess.Database
{
    public class CISODS
    {
        private CISODSContext Context { get; }

        public CISODS(CISODSContext context)
        {
            Context = context;
        }

        public void TruncateBU022()
        {
            Context.Database.ExecuteSqlCommand("DELETE FROM Internal.BU022");
        }

        public List<BU022> GetBU022Merges()
        {
            return Context.BU022.ToList();
        }

        public void DeleteBU022Row(decimal CUSNBRMRG, decimal CUSNBR)
        {
            Context.BU022.RemoveRange(Context.BU022.Where(x => x.CUSNBRMRG == CUSNBRMRG && x.CUSNBR == CUSNBR));
            Context.SaveChanges();
        }
    }
}
