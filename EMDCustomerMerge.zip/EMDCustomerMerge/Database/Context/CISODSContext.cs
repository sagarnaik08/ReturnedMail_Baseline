﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using EMDDatabaseAccess.DataModels.CISODS;

namespace EMDDatabaseAccess.Database.Context
{
    public class CISODSContext : DbContext
    {
        static string Defaultconnection = "Data Source =DVSQODSDW02\\instance01; Initial Catalog = CISODS; Integrated Security = true";


        public CISODSContext() : base(Defaultconnection)
        {

        }

        public CISODSContext(string connectionstring)
        {

            this.Database.Connection.ConnectionString = connectionstring;
        }

        public DbSet<BU022> BU022 { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BU022>().ToTable("Internal.BU022").HasKey(x => new { x.CUSNBRMRG, x.CUSNBR, x.GLB_DTIME });
        }
    }
}
