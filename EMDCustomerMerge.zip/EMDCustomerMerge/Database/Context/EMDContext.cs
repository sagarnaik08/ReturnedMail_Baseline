﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using EMDDatabaseAccess.DataModels.EmptorDB;

namespace EMDDatabaseAccess.Database.Context
{
    public class EMDContext : DbContext
    {
        public static string Defaultconnection = "Data Source =dvemptordw04.devadmin.nbsdev.co.uk,55551; Initial Catalog = EmptorDB; Integrated Security = true";
        public static string ConnectionString = @"DVEMPTORSW01.devadmin.nbsdev.co.uk,55551";

        public EMDContext() : base(Defaultconnection)
        {
            this.Database.CommandTimeout = 360;

        }

        public EMDContext(string connectionstring)
        {

            this.Database.Connection.ConnectionString = connectionstring;
        }

        public DbSet<ProcessLog> ProcessLog { get; set; }
        public DbSet<ProcessMaster> ProcessMaster { get; set; }
        public DbSet<CustomerMerge> CustomerMerge { get; set; }
        public DbSet<CustomerMergeRejectedRecord> CustomerMergeRejectedRecord { get; set; }
        public DbSet<WRK_Initial_CustomerMergeData> WRK_Initial_CustomerMergeData { get; set; }
        public DbSet<AuditTable> AuditTable { get; set; }

        public DbSet<WRK_ReturnedMailCustomerDetails> WRK_ReturnedMailCustomerDetails { get; set; }

        public DbSet<RM_MI_Exception> RM_MI_Exception { get; set; }

        public DbSet<RM_MI_Measure> RM_MI_Measure { get; set; }

        public DbSet<RM_MI_Measure_Summary_View> RM_MI_Measure_Summary_View { get; set; }

        public DbSet<RM_MI_Exception_Summary_View> RM_MI_Exception_Summary_View { get; set; }

        public DbSet<RM_MI_Detail_View> RM_MI_Detail_View { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProcessLog>().ToTable("Admin.ProcessLog").HasKey(x => x.LogID);
            modelBuilder.Entity<ProcessMaster>().ToTable("Admin.ProcessMaster").HasKey(x => x.ProcessID);

            modelBuilder.Entity<CustomerMerge>().ToTable("Internal.CustomerMerge").HasKey(x => new { x.MergedTo, x.MergedFrom, x.MergeDate });
            modelBuilder.Entity<CustomerMergeRejectedRecord>().ToTable("Internal.CustomerMergeRejectedRecords").HasKey(x => x.RejectId);

            modelBuilder.Entity<WRK_Initial_CustomerMergeData>().ToTable("Staging.WRK_Initial_CustomerMergeData").HasKey(x => new { x.CUSNBRMRG, x.CUSNBR, x.GLB_DTIME });
            modelBuilder.Entity<AuditTable>().ToTable("internal.CustomerMergeAudit").HasKey(x => x.AuditID);

            modelBuilder.Entity<WRK_ReturnedMailCustomerDetails>().ToTable("Staging.WRK_ReturnedMailCustomerDetails").HasKey(x => new { x.PartyId, x.AlertCreatedDate });
            modelBuilder.Entity<RM_MI_Exception>().ToTable("Reporting.RM_MI_Exception").HasKey(x => new { x.RMMIExceptionID});
            modelBuilder.Entity<RM_MI_Measure>().ToTable("Reporting.RM_MI_Measure").HasKey(x => new { x.EmailAddressUnavailable_COUNT });
            modelBuilder.Entity<RM_MI_Measure_Summary_View>().ToTable("ReturnedMail.RM_MI_Measure_Summary_View").HasKey(x => new { x.ExtractDay });
            modelBuilder.Entity<RM_MI_Exception_Summary_View>().ToTable("ReturnedMail.RM_MI_Exception_Summary_View").HasKey(x => new { x.ExtractDay });
            modelBuilder.Entity<RM_MI_Detail_View>().ToTable("Reporting.RM_MI_Detail_View").HasKey(x => new { x.PartyID });        
        }
    }
}

