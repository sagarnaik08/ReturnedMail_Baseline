﻿using EMDDatabaseAccess.Database.Context;
using System.Data.SqlClient;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Smo.Agent;
using EMDDatabaseAccess.DataModels.EmptorDB;

namespace EMDDatabaseAccess.Database
{
    public class EMD
    {
        private EMDContext Context { get; }

        public EMD(EMDContext context)
        {
            Context = context;
        }

        public void TruncateCustomerMergeInitialLoadStaging()
        {
            Context.Database.ExecuteSqlCommand("DELETE FROM Staging.WRK_Initial_CustomerMergeData");
        }

        public void TruncateCustomerMergeRejectRecords()
        {
            Context.Database.ExecuteSqlCommand("DELETE FROM Internal.CustomerMergeRejectedRecords");
        }
        public void TruncateCustomerMergeTable()
        {
            Context.Database.ExecuteSqlCommand("DELETE FROM Internal.CustomerMerge");
        }
        public void RunCustomerMergeInitialLoad()
        {
            Context.Database.ExecuteSqlCommand("Internal.usp_InitialLoadCustomerMerge @ProcessName", new SqlParameter("ProcessName", "LoadCustomerMerge"));
        }

        public void RunCustomerMergeRejectRecords()
        {
            Context.Database.ExecuteSqlCommand("Internal.usp_InitialLoadCustomerMergeRejectedRecords @ProcessName", new SqlParameter("ProcessName", "LoadCustomerMerge_RejectedRecords"));
        }

        public void RunCustomerMergeDeltaLoad()
        {
            //Context.Database.ExecuteSqlCommand("Internal.usp_DeltaLoadEmptor @ProcessName", new SqlParameter("ProcessName", "LoadCustomerMerge"));
            Context.Database.ExecuteSqlCommand("Internal.usp_DeltaLoadEmptor 'LoadCustomerMerge'");

        }
     

        public void RunReturnedCustomerLoad(List<WRK_ReturnedMailCustomerDetails>data)
        {
            Context.Database.ExecuteSqlCommand("DELETE FROM EmptorDB.Staging.WRK_ReturnedMailCustomerDetails");
            Context.Database.ExecuteSqlCommand("DELETE FROM EmptorDB.Reporting.RM_MI_Exception");
            Context.Database.ExecuteSqlCommand("DELETE FROM EmptorDB.Reporting.RM_MI_Measure");
            //Context.Database.ExecuteSqlCommand("INSERT INTO EmptorDB.Staging.WRK_ReturnedMailCustomerDetails (PartyId,AlertCreatedDate) VALUES(109,'2022-16-05 06:32:35.953')");
            Context.WRK_ReturnedMailCustomerDetails.AddRange(data);
            Context.SaveChanges();
        }

        public void RunReturnedMailStoredProcedure()
        {
            Context.Database.ExecuteSqlCommand("Declare @logid BIGINT select @logid =  MAX(logid) from admin.ProcessLog exec Reporting.usp_RM_MI_DailyMeasuresAndExceptions @logid, 'LastProcessedID'");
        }
        public List<AuditTable> GetAuditTable()
        {
            return Context.AuditTable.ToList();
        }
        public List<CustomerMerge> GetCustomerMerges()
        {
            return Context.CustomerMerge.ToList();
        }


        public List<CustomerMergeRejectedRecord> GetCustomerMergeRejectedRecords()
        {
            return Context.CustomerMergeRejectedRecord.ToList();
        }

        public List<WRK_ReturnedMailCustomerDetails> WRK_ReturnedMailCustomerDetails()
        {
            return Context.WRK_ReturnedMailCustomerDetails.ToList();
        }
        
        public List<RM_MI_Exception> RM_MI_Exception()
        {
            return Context.RM_MI_Exception.ToList();
        }

        public List<RM_MI_Measure> RM_MI_Measure()
        {
            return Context.RM_MI_Measure.ToList();
        }

        public List<RM_MI_Measure_Summary_View> RM_MI_Measure_Summary_View()
        {
            return Context.RM_MI_Measure_Summary_View.ToList();
        }

        public List<RM_MI_Exception_Summary_View> RM_MI_Exception_Summary_View()
        {
            return Context.RM_MI_Exception_Summary_View.ToList();
        }

        public List<RM_MI_Detail_View> RM_MI_Detail_View()
        {
            return Context.RM_MI_Detail_View.ToList();
        }

        public ProcessLog GetProcessLog(string processName)
        {
            var customerMergeProcess = Context.ProcessMaster.Where(x => x.ProcessName == processName).First();
            var processLog = new ProcessLog()
            {
                ProcessID = customerMergeProcess.ProcessID,
                StartTime = DateTime.Now,
                Status = "Running"
            };
            Context.ProcessLog.Add(processLog);
            Context.SaveChanges();
            return processLog;
        }

        public void RunCustomerMergeInitialLoadAgentJob()
        {
            RunAgentJob("Job_InitialLoad_CustomerMerge");
        }

        public void RunFileCreationReturnedMailJob()
        {
            RunAgentJob("Job_EMD_FileCreation_ReturnedMail");
        }

     

        public void RunAgentJob(string jobName)
        {
            var server = new Server(EMDContext.ConnectionString);

            try
            {
                server.ConnectionContext.LoginSecure = true;
                server.ConnectionContext.Connect();

                var job = server.JobServer.Jobs[jobName];
                job.Start();

                Thread.Sleep(1000);
                job.Refresh();

                while (job.CurrentRunStatus == JobExecutionStatus.Executing)
                {
                    // Wait until job completes (agent jobs run in background process unlike stored procedures)
                    Thread.Sleep(1000);
                    job.Refresh();
                }

            }
            finally
            {
                if (server.ConnectionContext.IsOpen)
                {
                    server.ConnectionContext.Disconnect();
                }
            }

        }
    }
}
